#الكراك من قبل القراصنة الروسي اللعنة عليك أعداء
import os
import sys
import requests
import time
import random
from random import randint

os.system('clear')

logo = ("""
######## ########     ########  #######   #######  ##       ##    ## #### ########
##       ##     ##       ##    ##     ## ##     ## ##       ##   ##   ##     ##
##       ##     ##       ##    ##     ## ##     ## ##       ##  ##    ##     ##
######   ########        ##    ##     ## ##     ## ##       #####     ##     ##
##       ##     ##       ##    ##     ## ##     ## ##       ##  ##    ##     ##
##       ##     ##       ##    ##     ## ##     ## ##       ##   ##   ##     ##
##       ########        ##     #######   #######  ######## ##    ## ####    ##
╔════════════════════════════════════════════════════════════════════════════════╗
║ [✓] Author     : Rodel C Tarrayo Jr                                            ║
║ [✓] Tool       : Facebook Toolkit                                              ║
║ [✓] Status     : Premium                                                       ║
║ [✓] System     : Data & Wi-Fi                                                  ║
║ [✓] GitHub     : HAXOR-BD1                                                     ║
║ [✓] Facebook   : Rodel C Tarrayo Jr.                                           ║
║ [✓] Version    : 1.5                                                           ║
║ [✓] Added Tool : 4                                                             ║
╠════════════════════════════════════════════════════════════════════════════════╝""")

class Main:
    def __init__(self):
        user=[]
        os.system('clear')
        print(logo)
        print ('║==> [01] Facebook Cloning')
        print ('║==> [02] Facebook Toolkit')
        print ('║==> [03] AdminHack')
        print ('║==> [04] Facebook Bot')
        print ('║==> [05] CCTV Hacking')
        print ('║==> [06] Ddos Attack')
        print ('║==> [07] Sms Bomber')
        print ('║==> [08] Contact Me')
        print ('║==> [00] Exit')
        tool =input('╚═══>> ')
        if tool in ['1', '01']:
            rcrack()
        if tool in ['2', '02']:
            fbtool()
        if tool in ['3', '03']:
            admin()
        if tool in ['4', '04']:
            bot()
        if tool in ['5', '05']:
            cctv()
        if tool in ['6', '06']:
            ddos()
        if tool in ['7', '07']:
            sms()
        if tool in ['8', '08']:
            contact()
        if tool in ['0', '00']:
            exit()
        else:
            Main()

def rcrack():
    user=[]
    os.system('python .clone.py')

def fbtool():
    user=[]
    os.system('python2 .toolkit.py')

def admin():
    user=[]
    os.system('bash .admin.sh')

def bot():
    user=[]
    os.system('php .bot.php')

def cctv():
    user=[]
    os.system('python3 .cctv.py')

def ddos():
    user=[]
    os.system('python .ddos.py')

def sms():
    user=[]
    os.system('python .SMS.py')

def contact():
    user=[]
    os.system('xdg-open https://www.facebook.com/profile.php?id=100075799751503')
Main()
